A Pen created at CodePen.io. You can find this one at http://codepen.io/Em-Ant/pen/QbRyqq.

 Exercise ("Zipline") I5 for the new www.freecodecamp.com curriculum. It'uses the new AudioContext API, so you need an up-to-date browser to run it. 