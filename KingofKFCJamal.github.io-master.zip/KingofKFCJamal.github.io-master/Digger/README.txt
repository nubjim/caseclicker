A Pen created at CodePen.io. You can find this one at http://codepen.io/caiiiycuk/pen/rOPXeL.

 A Digger video game for http://js-dos.com/getting-started/