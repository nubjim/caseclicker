A Pen created at CodePen.io. You can find this one at http://codepen.io/jackrugile/pen/IHbvh.

 This is a basic snake game made with JavaScript for logic and CSS for rendering. Use the arrow keys or WASD to control the snake. You can loop through walls.

Good luck! Post your high score in the comments.