A Pen created at CodePen.io. You can find this one at http://codepen.io/pixelass/pen/wBRxjB.

 Edgars Lair is a simple game written in pure CSS. You can move the character around, go to other rooms, talk to people, look at objects or take a nap. Enjoy the awesomeness of pure CSS.

#### Walking
1. click ctrl + alt + [W,A,S,D]  
2. then space 

* or click buttons (upper left corner)
 
#### Other rooms
* click on doors/wall-gaps 

#### Talk
* click on objects or people 

#### Browser support
Tested in  

* OS X
  * Chrome
  * Firefox
  * Safari
  * Opera
* Windows
  * Chrome
  * Firefox
  * Opera
* Android
  * Chrome
  * Firefox

Keyboard access not working? find out how to use accesskey in your browser/OS http://en.wikipedia.org/wiki/Access_key

Still not working? drop a comment

