A Pen created at CodePen.io. You can find this one at http://codepen.io/ebrewe/pen/MamqXM.

 It's the bones of a 2D  infinite runner game. I'm using Phaser's P2 physics for slopes. 