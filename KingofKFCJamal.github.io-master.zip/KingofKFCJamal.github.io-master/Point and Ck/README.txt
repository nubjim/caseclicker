A Pen created at CodePen.io. You can find this one at http://codepen.io/TimPietrusky/pen/LrAtd.

 A very basic prototype for a browser game. Best experience in fullscreen!

Photos by @haukebruno