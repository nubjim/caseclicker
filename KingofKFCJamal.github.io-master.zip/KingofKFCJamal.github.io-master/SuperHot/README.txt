A Pen created at CodePen.io. You can find this one at http://codepen.io/benjaminmiles/pen/PNoXdQ.

 A quick weekend prototype to try and replicate the SUPERHOT time warp effect. Your movement directly affects the speed of time. Move quickly and the game ascends to real time. Slow down and the game does the same.

Move with your arrow keys. Shoot with the spacebar. Keyboard only.

Based on and inspired by:
https://superhotgame.com

Built using:
http://phaser.io

Learn more:
http://www.benjaminmiles.com/blog/2016/2/29/superhot-2d