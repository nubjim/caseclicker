A Pen created at CodePen.io. You can find this one at http://codepen.io/sakri/pen/gGahJ.

 My entry for #lowrezjam2014.  A functioning Flappy Bird in only 32 pixels by 32 pixels resolution.  Not too shabby for 10kb (not minified, including sprite sheet),  240 lines of javascript :)